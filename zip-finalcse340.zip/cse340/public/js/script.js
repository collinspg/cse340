document
  .querySelector(".nav__hamburger-menu")
  .addEventListener("click", function () {
    document.querySelector(".nav__menu").classList.toggle("active");
    // document.querySelector(".menu").classList.toggle("active");
  });